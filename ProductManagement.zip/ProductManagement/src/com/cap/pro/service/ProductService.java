package com.cap.pro.service;

import java.util.HashMap;

import com.cap.pro.bean.client;
import com.cap.pro.dao.ProductDAO;
import com.cap.pro.exception.ProductException;

public class ProductService implements IProductService {
	Validation valid=new Validation();
	client c=new client();
	ProductDAO dao=new ProductDAO();
	

	@Override
	public int updateProducts(String Category, int hike) throws ProductException {
		if(!valid.validatecategory(Category))
			{throw new ProductException("Invalid category");
			}
		if(!valid.validatehike(hike))
			throw new ProductException("Enter Postive Integer");
		return dao.updateProducts(Category, hike);
	}

	@Override
	public HashMap<String, Integer> getProductDetails() throws ProductException {
		
		return dao.getProductDetails();
	}
}
