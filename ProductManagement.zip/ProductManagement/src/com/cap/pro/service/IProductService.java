package com.cap.pro.service;

import java.util.HashMap;

import com.cap.pro.exception.ProductException;

public interface IProductService {
public int updateProducts(String Category,int hike) throws ProductException;
	
	public HashMap<String, Integer> getProductDetails() throws ProductException;
}
